#!/usr/bin/env python
# coding: utf-8

# # E5 Assignment | Siddharth Verma | 22B2153

# #  Problem 1

# In[154]:


import pandas as pd
import numpy as np 
import matplotlib.pyplot as plt


# In[155]:


import plotly.graph_objects as go


# In[156]:


import seaborn as sns


# In[157]:


data=pd.read_csv("e5-htr-currernt.csv")


# ## Checking Info on csv data

# In[158]:


data.info()


# In[159]:


data


# In[160]:


data.describe()


# In[161]:


data.isna().sum()


# In[162]:


data.describe()


# In[163]:


data.info()


# In[164]:


df=data


# In[165]:


import plotly.graph_objects as go

# Convert 'Timestamp' column to datetime format
df['Timestamp'] = pd.to_datetime(df['Timestamp'], format='%d-%m-%Y %H:%M')

# Visualize time series data
fig = go.Figure()
fig.add_trace(go.Scatter(x=df['Timestamp'], y=df['HT R Phase Current'], mode='lines', name='HT R Phase Current'))
fig.update_layout(title='Time Series of HT R Phase Current', xaxis_title='Timestamp', yaxis_title='HT R Phase Current')
fig.show()


# In[166]:


# Plot histogram of 'HT R Phase Current'
plt.figure(figsize=(10, 6))
plt.hist(df['HT R Phase Current'], bins=30, color='skyblue', edgecolor='black')
plt.title('Histogram of HT R Phase Current')
plt.xlabel('HT R Phase Current')
plt.ylabel('Frequency')
plt.grid(True)
plt.show()


# In[167]:


# Convert 'Timestamp' column to datetime format
df['Timestamp'] = pd.to_datetime(df['Timestamp'], format='%d-%m-%Y %H:%M')

# Calculate rolling standard deviation with a window size of 24 hours (1 day)
rolling_std = df['HT R Phase Current'].rolling(window=336).std()

# Create a Plotly figure
fig = go.Figure()

# Add a scatter plot for the rolling standard deviation
fig.add_trace(go.Scatter(x=df['Timestamp'], y=rolling_std, mode='lines', name='Rolling Std Deviation', line=dict(color='orange')))

# Update layout
fig.update_layout(title='Rolling Standard Deviation of HT R Phase Current',
                  xaxis_title='Timestamp',
                  yaxis_title='Rolling Standard Deviation',
                  showlegend=True,
                  template='plotly_dark')

# Show plot
fig.show()


# In[168]:


import pandas as pd
import numpy as np
from scipy import stats
from sklearn.ensemble import IsolationForest
from sklearn.impute import KNNImputer
from statsmodels.tsa.seasonal import seasonal_decompose, STL
import plotly.graph_objects as go

# Load the data
df = data  # Load your data file here
df['Timestamp'] = pd.to_datetime(df['Timestamp'], format='%d-%m-%Y %H:%M')
df.set_index('Timestamp', inplace=True)

# Extract data segment from August 27, 2019, to September 10, 2019
data_segment = df['2019-08-27':'2019-09-10']

# Method 1: Outlier Removal using Z-score method
z_scores = np.abs(stats.zscore(data_segment['HT R Phase Current']))
outlier_threshold = 3
outlier_indices = np.where(z_scores > outlier_threshold)[0]
cleaned_data1_zscore = data_segment.drop(data_segment.index[outlier_indices])

# Method 2: Data Smoothing using Moving Average with window size 3
smoothed_data2_ma = data_segment['HT R Phase Current'].rolling(window=3, min_periods=1).mean()

# Method 3: Missing Data Imputation using Linear Interpolation
interpolated_data3_linear = data_segment['HT R Phase Current'].interpolate(method='linear')

# Method 4: Outlier Removal using Isolation Forest
isolation_forest = IsolationForest(contamination='auto', random_state=42)
outliers = isolation_forest.fit_predict(data_segment[['HT R Phase Current']])
cleaned_data1_isolation = data_segment[outliers == 1]

# Method 5: Data Smoothing using Exponential Moving Average (EMA)
smoothed_data2_ema = data_segment['HT R Phase Current'].ewm(span=3, adjust=False).mean()

# Method 6: Missing Data Imputation using K-Nearest Neighbors (KNN)
knn_imputer = KNNImputer(n_neighbors=5)
imputed_data3_knn = knn_imputer.fit_transform(data_segment[['HT R Phase Current']])
imputed_data3_knn = pd.DataFrame(imputed_data3_knn, index=data_segment.index, columns=['HT R Phase Current'])



# Plot original and processed data for both sets of methods
fig = go.Figure()

# Original and processed data for the first set of methods
fig.add_trace(go.Scatter(x=data_segment.index, y=data_segment['HT R Phase Current'], mode='lines', name='Original Data'))
fig.add_trace(go.Scatter(x=cleaned_data1_zscore.index, y=cleaned_data1_zscore['HT R Phase Current'], mode='lines', name='Cleaned Data (Z-score)'))
fig.add_trace(go.Scatter(x=data_segment.index, y=smoothed_data2_ma, mode='lines', name='Smoothed Data (Moving Average)'))
fig.add_trace(go.Scatter(x=data_segment.index, y=interpolated_data3_linear, mode='lines', name='Interpolated Data (Linear)'))

# Original and processed data for the second set of methods
fig.add_trace(go.Scatter(x=data_segment.index, y=data_segment['HT R Phase Current'], mode='lines', name='Original Data'))
fig.add_trace(go.Scatter(x=cleaned_data1_isolation.index, y=cleaned_data1_isolation['HT R Phase Current'], mode='lines', name='Cleaned Data (Isolation Forest)'))
fig.add_trace(go.Scatter(x=data_segment.index, y=smoothed_data2_ema, mode='lines', name='Smoothed Data (EMA)'))
fig.add_trace(go.Scatter(x=imputed_data3_knn.index, y=imputed_data3_knn['HT R Phase Current'], mode='lines', name='Imputed Data (KNN)'))

fig.update_layout(title='Combined Data Processing Methods',
                  xaxis_title='Timestamp',
                  yaxis_title='HT R Phase Current',
                  showlegend=True,
                  template='plotly_dark')

fig.show()


# # Metrics of above Test

# In[180]:


# Assuming data_segment, cleaned_data1_zscore, smoothed_data2_ma, interpolated_data3_linear,
# cleaned_data1_isolation, smoothed_data2_ema, and imputed_data3_knn are DataFrames

# Combine descriptions along columns axis
combined_descriptions = pd.concat([data_segment.describe(), 
                                    cleaned_data1_zscore.describe(), 
                                    smoothed_data2_ma.describe(), 
                                    interpolated_data3_linear.describe(), 
                                    cleaned_data1_isolation.describe(), 
                                    smoothed_data2_ema.describe(), 
                                    imputed_data3_knn.describe()], 
                                   axis=1)

# Print the combined descriptions in a nicely formatted table
print(combined_descriptions.to_string())


# In[187]:


data_segment.describe()


# In[189]:


cleaned_data1_zscore.describe()


# In[190]:


smoothed_data2_ma.describe()


# In[191]:


interpolated_data3_linear.describe()


# In[192]:


cleaned_data1_isolation.describe()


# In[193]:


smoothed_data2_ema.describe()


# In[194]:


imputed_data3_knn.describe()


# # Problem 2

# In[8]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


# In[9]:


d1=pd.read_csv("e5-Run2-June22-subset-100-cols.csv",index_col="c1")


# In[10]:


# Set the option to display all columns
pd.set_option('display.max_columns', None)

# Display the DataFrame with all columns
d1


# In[11]:


d1.head()


# In[12]:


d1.describe()


# In[19]:


d1.info()


# # Note c57 has 13 null values c59 has 31 null values

# # Creating Pair Plot and Heat Map

# In[57]:


import pandas as pd
import numpy as np
from sklearn.impute import KNNImputer
import seaborn as sns
import matplotlib.pyplot as plt

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
# Step 1: Read the CSV file
df = d1

# Step 2: Handle missing values (if any)
# Replace missing values with NaN
df.replace('?', np.nan, inplace=True)

# Convert non-numeric values to NaN
df = df.apply(pd.to_numeric, errors='coerce')

# Step 3: Impute missing values using k-NN
# Initialize the KNNImputer
imputer = KNNImputer(n_neighbors=5)  # You can adjust the number of neighbors as per your dataset

# Perform imputation
df_imputed = pd.DataFrame(imputer.fit_transform(df), columns=df.columns)

# Step 4: Compute the correlation matrix
correlation_matrix = df_imputed.corr()

# Step 5: Filter correlation matrix to keep only strong correlations
threshold = 0.75  # Adjust the threshold as per your preference
strong_correlations = correlation_matrix[(correlation_matrix > threshold) | (correlation_matrix < -threshold)]

# Step 6: Visualize the correlation heatmap
plt.figure(figsize=(10, 8))
sns.heatmap(strong_correlations, annot=True, cmap='coolwarm', fmt=".2f")
plt.title('Strong Correlation Heatmap (Threshold: {})'.format(threshold))
plt.show()



# # Note I have taken Threshold as high 0.75 so as to see which columns must be discarded

# In[28]:


import pandas as pd
import numpy as np
from sklearn.impute import KNNImputer
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

# Step 1: Read the CSV file
df = d1

# Step 2: Handle missing values (if any)
# Replace missing values with NaN
df.replace('?', np.nan, inplace=True)

# Convert non-numeric values to NaN
df = df.apply(pd.to_numeric, errors='coerce')

# Step 3: Impute missing values using k-NN
# Initialize the KNNImputer
imputer = KNNImputer(n_neighbors=5)  # You can adjust the number of neighbors as per your dataset

# Perform imputation
df_imputed = pd.DataFrame(imputer.fit_transform(df), columns=df.columns)

# Step 4: Standardize the data
scaler = StandardScaler()
scaled_data = scaler.fit_transform(df_imputed)

# Step 5: Apply PCA
pca = PCA(n_components=0.95)  # Retain 95% of variance
principal_components = pca.fit_transform(scaled_data)

# Print the explained variance ratio and the number of components required
print("Explained Variance Ratio:", pca.explained_variance_ratio_)
print("Number of Components Required to Retain 95% Variance:", pca.n_components_)

# Create DataFrame from principal components
pc_df = pd.DataFrame(data=principal_components,
                     columns=[f'PC{i+1}' for i in range(principal_components.shape[1])])

# Calculate correlations between principal components
correlation_matrix = pc_df.corr()

# Create the heatmap
plt.figure(figsize=(12, 8))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".2f")
plt.title('Heatmap of Correlations Between Principal Components')
plt.show()


# In[64]:


import pandas as pd
import numpy as np
from sklearn.impute import KNNImputer
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

# Step 1: Read the CSV file
df = d1

# Step 2: Handle missing values (if any)
# Replace missing values with NaN
df.replace('?', np.nan, inplace=True)

# Convert non-numeric values to NaN
df = df.apply(pd.to_numeric, errors='coerce')

# Step 3: Impute missing values using k-NN
# Initialize the KNNImputer
imputer = KNNImputer(n_neighbors=5)  # You can adjust the number of neighbors as per your dataset

# Perform imputation
df_imputed = pd.DataFrame(imputer.fit_transform(df), columns=df.columns)

# Step 4: Standardize the data
scaler = StandardScaler()
scaled_data = scaler.fit_transform(df_imputed)

# Step 5: Apply PCA
pca = PCA()  # No need to specify n_components here
principal_components = pca.fit_transform(scaled_data)

# Plot the scree plot
plt.figure(figsize=(10, 6))
plt.plot(np.cumsum(pca.explained_variance_ratio_), marker='o', linestyle='-')
plt.xlabel('Number of Components')
plt.ylabel('Cumulative Explained Variance')
plt.title('Scree Plot')
plt.grid(True)

# Find the index where cumulative explained variance first crosses 0.95
idx = np.argmax(np.cumsum(pca.explained_variance_ratio_) >= 0.95)

# Plot a vertical line and a marker at that index
plt.axvline(x=idx, color='r', linestyle='--')
plt.text(idx, 0.96, f'{idx+1} components', rotation=90, color='r')

plt.show()


# In[81]:


# Step 1: Import necessary libraries
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from statsmodels.stats.outliers_influence import variance_inflation_factor

# Assuming df_imputed is your DataFrame
df = df_imputed
# Step 3: Handle multicollinearity by dropping columns with high VIF values
threshold_vif = 10  # You can adjust the threshold as needed

# Calculate VIF values
vif_df = calculate_vif(df)

# Identify columns with high VIF values
high_vif_columns = vif_df[vif_df['VIF'] > threshold_vif]['Feature']

# Drop columns with high VIF values
df_filtered = df.drop(columns=high_vif_columns)

# Step 4: Calculate VIF values again on filtered DataFrame
vif_df_filtered = calculate_vif(df_filtered)

# Step 5: Plot the VIF values
plt.figure(figsize=(10, 6))
sns.barplot(x='VIF', y='Feature', data=vif_df_filtered, palette='viridis')
plt.title('VIF Map (After Filtering)')
plt.xlabel('VIF Value')
plt.ylabel('Features')
plt.show()




# 

# In[82]:


from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

# Step 6: Standardize the features
scaler = StandardScaler()
df_standardized = scaler.fit_transform(df_filtered)

# Step 7: Perform PCA
pca = PCA()
pca.fit(df_standardized)
explained_variance_ratio = pca.explained_variance_ratio_

# Step 8: Plot explained variance ratio
plt.figure(figsize=(10, 6))
plt.plot(range(1, len(explained_variance_ratio) + 1), explained_variance_ratio, marker='o', linestyle='-')
plt.title('Explained Variance Ratio')
plt.xlabel('Number of Components')
plt.ylabel('Explained Variance Ratio')
plt.xticks(range(1, len(explained_variance_ratio) + 1))
plt.grid(True)
plt.show()


# In[83]:


from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

# Assuming df_filtered is your DataFrame after handling multicollinearity using VIF

# Step 1: Standardize the features
scaler = StandardScaler()
df_standardized = scaler.fit_transform(df_filtered)

# Step 2: Perform PCA
pca = PCA()
pca.fit(df_standardized)
explained_variance_ratio = pca.explained_variance_ratio_

# Step 3: Determine the number of components for 95% variance explained
cumulative_variance_ratio = np.cumsum(explained_variance_ratio)
components_for_95_variance = np.argmax(cumulative_variance_ratio >= 0.95) + 1

print("Number of components for 95% variance explained:", components_for_95_variance)


# # As  visible after VIF keeping VIF threshold as 10 our components required for 95% was reduced to 16 from 32

# # VIF < 10: This is a more lenient threshold and is commonly used. It suggests moderate multicollinearity.

# In[ ]:





# # Problem 3

# In[91]:


import pandas as pd
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt

# Load the dataset
mnist_test = pd.read_csv('mnist_test.csv')

# Perform PCA
pca = PCA()
pca.fit(mnist_test)

# Explained variance ratio
explained_variance_ratio = pca.explained_variance_ratio_

# Cumulative explained variance ratio
cumulative_variance_ratio = explained_variance_ratio.cumsum()

# Print explained variance ratio
print("Explained variance ratio:\n", explained_variance_ratio)

# Print cumulative explained variance ratio
print("\nCumulative explained variance ratio:\n", cumulative_variance_ratio)


# In[98]:


# Plot the scree plot
plt.figure(figsize=(10, 6))
plt.plot(np.cumsum(pca.explained_variance_ratio_), marker='o', linestyle='-')
plt.xlabel('Number of Components')
plt.ylabel('Cumulative Explained Variance')
plt.title('Scree Plot')
plt.grid(True)

# Find the index where cumulative explained variance first crosses 0.95
idx = np.argmax(np.cumsum(pca.explained_variance_ratio_) >= 0.95)

# Plot a vertical line and a marker at that index
plt.axvline(x=idx, color='r', linestyle='--')
plt.text(idx, 0.96, f'{idx+1} components', rotation=90, color='r')

plt.show()


# # 49 components make 0.95 variance of data

# In[93]:


# Transform the data to principal component space
mnist_test_pca = pca.transform(mnist_test)

# Scatter plot of PC2 vs PC1
plt.scatter(mnist_test_pca[:, 0], mnist_test_pca[:, 1])
plt.title('Scatter Plot of PC2 vs PC1')
plt.xlabel('Principal Component 1')
plt.ylabel('Principal Component 2')
plt.grid(True)
plt.show()


# In[94]:


from sklearn.manifold import TSNE

# Perform t-SNE analysis
tsne = TSNE(n_components=2)
mnist_test_tsne = tsne.fit_transform(mnist_test)


# In[95]:


# Scatter plot of t-SNE mapped data
plt.scatter(mnist_test_tsne[:, 0], mnist_test_tsne[:, 1])
plt.title('t-SNE Mapped Data')
plt.xlabel('t-SNE Dimension 1')
plt.ylabel('t-SNE Dimension 2')
plt.grid(True)
plt.show()


# In[97]:


# Load the dataset
e5_run2 = df_imputed

# Perform t-SNE analysis
e5_run2_tsne = tsne.fit_transform(e5_run2)

# Visualize the mapped data
plt.scatter(e5_run2_tsne[:, 0], e5_run2_tsne[:, 1])
plt.title('t-SNE Mapped Data (e5-Run2)')
plt.xlabel('t-SNE Dimension 1')
plt.ylabel('t-SNE Dimension 2')
plt.grid(True)
plt.show()


# In[ ]:




